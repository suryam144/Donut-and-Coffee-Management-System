package com.example.cs213_p5;
import java.text.DecimalFormat;

/**
 * Donut Class, which creates an implementation of a Donut item
 * @authors Isabelle Chang, Surya Mantha
 */
public class Donut extends MenuItem{
    private String menuType;
    private String donutType;
    private String donutName;
    private double donutPrice;
    private int donutAmt;

    /**
     * Creates an instance of a Donut item
     * @param menuType String: Specification of type of item
     * @param donutType String: Specification of type of Donut
     * @param donutName String: Specification of name of Donut
     * @param donutAmt Integer: States how many donuts are being ordered
     */
    public Donut(String menuType, String donutType, String donutName, int donutAmt){
        super(menuType);
        this.donutType = donutType;
        this.donutName = donutName;
        this.donutAmt = donutAmt;
        donutPrice = 0;
    }

    /**
     * Method that returns the type of donut inputted
     * @return String: Returns type of donut
     */
    public String getType(){
        return donutType;
    }

    /**
     * Method that returns name of donut inputted
     * @return String: Return name of donut
     */
    public String getName(){
        return donutName;
    }

    /**
     * Method that returns the price of a donut
     * @return Double: Returns price of a donut
     */
    @Override
    public double itemPrice(){
        DecimalFormat fmt = new DecimalFormat("##,###0.00");
        if(donutType.equals("Yeast")){donutPrice = Double.parseDouble(fmt.format(1.59));}
        else if(donutType.equals("Cake")){donutPrice = Double.parseDouble(fmt.format(1.79));}
        else if(donutType.equals("Holes")){donutPrice = Double.parseDouble(fmt.format(0.39));}
        else {donutPrice = Double.parseDouble(fmt.format(0));}
        donutPrice = donutPrice * donutAmt;
        return Double.parseDouble(fmt.format(donutPrice));
    }

    /**
     * Method that returns a donut item as a string
     * @return String: Components of a donut as a string
     */
    @Override
    public String toString(){
        return super.toString() +  "::" + donutType + "::" + donutName + "::Amount: " + donutAmt + "::Cost: "+ itemPrice();
    }
}
