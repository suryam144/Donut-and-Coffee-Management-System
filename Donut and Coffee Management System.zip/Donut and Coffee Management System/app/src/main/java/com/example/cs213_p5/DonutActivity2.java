package com.example.cs213_p5;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * DonutActivity2 class, which creates an implementation of the DonutMainView page and allows you to select a type of donut
 * @authors Isabelle Chang, Surya Mantha
 */
public class DonutActivity2 extends AppCompatActivity {

    private ArrayList<DonutModel> donutModels = new ArrayList<>();

    private int[] donutImages = {R.drawable.chocoglazeddh, R.drawable.glazeddh, R.drawable.powdereddh, R.drawable.pumpkindh,
            R.drawable.bcyeast, R.drawable.cfyeast, R.drawable.sfyeast, R.drawable.vfyeast,
            R.drawable.bbcake, R.drawable.cscake, R.drawable.cncake, R.drawable.sccake};

    private static final double holesCost = 0.39;
    private static final double yeastCost = 1.59;
    private static final double cakeCost = 1.79;

    /**
     * Method that creates the DonutActivity2 scene upon selection in the MainActivity page
     * @param savedInstanceState Bundle used to create the DonutActivity2 scene
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.donut_main_view);
        RecyclerView donutRecycler = findViewById(R.id.donutRecyclerView);
        setupDonutModels();
        DonutAdapter2 donutAdapter2 = new DonutAdapter2(this, donutModels);
        donutRecycler.setAdapter(donutAdapter2);
        donutRecycler.setLayoutManager(new LinearLayoutManager((this)));
    }

    /**
     * Method that sets up Donut Models for later use to be ordered
     */
    private void setupDonutModels() {
        String[] donutFlavors = getResources().getStringArray(R.array.donutFlavors);
        String[] donutPrices = getResources().getStringArray(R.array.donutPrices);
        for(int i = 0; i < donutFlavors.length; i++) {
            donutModels.add(new DonutModel(donutFlavors[i], donutPrices[i], donutImages[i]));
        }
    }

    /**
     * Mtethod that lets the user move to another page regardless of how many donuts have been ordered
     * @param view View of DonutActivity2, where donuts are selected
     */
    public void viewDonutOrder(View view) {
        //let user go to this page regardless of how many donuts they've ordered
        //in donutorder activity, handle exceptions (e.g., )
        Intent intent = new Intent(this, DonutOrderActivity.class);
        startActivity(intent);
    }
}