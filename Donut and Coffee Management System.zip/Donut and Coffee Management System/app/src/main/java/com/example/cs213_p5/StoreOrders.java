package com.example.cs213_p5;

import java.text.DecimalFormat;
import java.util.ArrayList;

/**
 * StoreOrders Class, which creates an implementation of a StoreOrder class
 */
public class StoreOrders implements Customizable{

    private ArrayList<Order> orderArr;
    private static final double SALES_TAX = 0.0625;

    /**
     * Creates an implementation of a StoreOrders item
     */
    public StoreOrders(){
        orderArr = new ArrayList<Order>();
    }

    /**
     * Method that adds an order to a StoreItem
     * @param obj Obj: MenuItem to be added to orders
     * @return True if successfully added
     */
    @Override
    public boolean add(Object obj) {
        Order tempOrder = (Order) obj;
        orderArr.add(tempOrder);
        return true;
    }
    /**
     * Method that removes an order to a StoreItem
     * @param obj Obj: MenuItem to be added to orders
     * @return True if successfully removed, false otherwise
     */
    @Override
    public boolean remove(Object obj) {
        Order tempOrder = (Order) obj;
        int index = -1;
        for(int i = 0; i < orderArr.size(); i++){
            if(orderArr.get(i).toString().equals(tempOrder.toString())){
                index = i;
            }
        }
        if(index == -1){return false;}
        orderArr.remove(index);
        return true;
    }

    /**
     * Method that returns the orders within a StoreOrder
     * @param tax Boolean: Determines if tax should be incorporated
     * @return String: String of all components of a StoreOrder
     */
    public String getOrders(boolean tax){
        DecimalFormat fmt = new DecimalFormat("##,###0.00");
        String temp = "**List of All Orders**\n";
        double tempPrice = 0;
        for (Order order : orderArr) {
            temp += ("\n" + order.printOrder(false) + "\n");
            tempPrice += order.orderTotal();
        }
        if(!tax){temp += "Total Cost of Orders: " + tempPrice + "\n";}
        else{temp += "Total Cost of Orders with Tax: " + fmt.format((tempPrice * SALES_TAX) + tempPrice) + "\n";}
        return temp + "**End of List**";
    }

    public ArrayList<Order> getOrderArr(){
        return orderArr;
    }
}
