package com.example.cs213_p5;

import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputEditText;

import java.text.DecimalFormat;
import java.util.ArrayList;

/**
 * Method that creates an instance of the ListOrdersActivity page, which manages all orders places
 * @authors Isabelle Chang, Surya Mantha
 */
public class ListOrdersActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener{

    ListView orderLV;
    Spinner soSpinner;
    TextInputEditText soOrderTotal;
    Button soCancelButton;
    private int listIndex;
    ArrayList<String> tempFinalStore = new ArrayList<>();
    private static final double SALES_TAX = 0.0625;

    /**
     * Method that creates the ListOrdersActivity scene upon selection in the MainActivity page
     * @param savedInstanceState Bundle used to create the ListOrdersActivity scene
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.list_orders_view);

        orderLV = findViewById(R.id.OrderLV);
        soSpinner = findViewById(R.id.spinner2);
        soOrderTotal = findViewById(R.id.soOrderTotal);
        soCancelButton = findViewById(R.id.soCancelButton);

        ArrayAdapter adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, tempFinalStore);
        orderLV.setAdapter(adapter);

        orderLV.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            /**
             * Method that finds the index of a selected ListView Item
             * @param adapterView adapterView of the listview
             * @param view view of the listview
             * @param i index of the list view
             * @param l long value for the list view when clicked
             */
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
            }
        });

        ArrayList<String> order = new ArrayList<>();
        for(int i = 0; i < MainActivity.getOrderStore().size(); i++){
            order.add((i+1)+"");
        }

        ArrayAdapter<String> adapterOne = new ArrayAdapter(this, android.R.layout.simple_spinner_item, order);
        adapterOne.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        soSpinner.setAdapter(adapterOne);
        soSpinner.setOnItemSelectedListener(this);
        DecimalFormat fmt = new DecimalFormat("##,###0.00");
        double tempPrice = 0;
        for (Order tempOrder : MainActivity.getOrderStore().get(listIndex).getOrderArr()) {
            tempPrice += tempOrder.orderTotal();
        }
        tempPrice = tempPrice + (tempPrice * SALES_TAX);
        soOrderTotal.setText("$" + fmt.format(tempPrice));

    }

    /**
     * Method that cancels an order within the Order List page
     * @param view View of sCancelOrder
     */
    public void sCancelOrder(View view) {
        listIndex = Integer.parseInt(soSpinner.getSelectedItem().toString()) - 1;
        MainActivity.getOrderStore().remove(listIndex);
        ArrayList<String> order = new ArrayList<>();
        for(int i = 0; i < MainActivity.getOrderStore().size(); i++){
            order.add((i+1)+"");
        }

        ArrayAdapter<String> adapterOne = new ArrayAdapter(this, android.R.layout.simple_spinner_item, order);
        adapterOne.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        soSpinner.setAdapter(adapterOne);
        soSpinner.setOnItemSelectedListener(this);
        Context context = getApplicationContext();
        Toast.makeText(context, "Order Cancelled.",Toast.LENGTH_SHORT).show();
        finish();

    }

    /**
     * Method used to calculate price on spinner selection
     * @param adapterView View of screen
     * @param view view of item select
     * @param i index of item location
     * @param l length at item location
     */
    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
        listIndex = Integer.parseInt(soSpinner.getSelectedItem().toString()) - 1;
        tempFinalStore.clear();
        tempFinalStore.add(MainActivity.getOrderStore().get(listIndex).getOrders(true));
        ArrayAdapter adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, tempFinalStore);
        orderLV.setAdapter(adapter);
        DecimalFormat fmt = new DecimalFormat("##,###0.00");
        double tempPrice = 0;
        for (Order order : MainActivity.getOrderStore().get(listIndex).getOrderArr()) {
            tempPrice += order.orderTotal();
        }
        tempPrice = tempPrice + (tempPrice * SALES_TAX);
        soOrderTotal.setText("$" + fmt.format(tempPrice));
    }

    /**
     * Loaded method required upon implementation
     * @param adapterView View of screen
     */
    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {
    }
}
