package com.example.cs213_p5;

import java.text.DecimalFormat;

/**
 * MenuItem class, which creates an instance of MenuItem for both the Donut and Coffee class
 * @authors Isabelle Chang, Surya Mantha
 */
public class MenuItem {
    private double priceAmt;
    private String menuType;

    /**
     * Creates an instance of a Menu item
     * @param menuType String: Deliniator of a donut or coffee item
     */
    public MenuItem(String menuType){
        this.menuType = menuType;
    }

    /**
     * Method that returns the price of an item
     * @return Double: Returns price of an item
     */
    public double itemPrice(){
        priceAmt = 0;
        return priceAmt;
    }

    /**
     * Method that returns MenuItem as a string
     * @return String: Components of Menu Item as a String
     */
    public String toString(){
        DecimalFormat fmt = new DecimalFormat("##,###0.00");
        return menuType;
    }

}
