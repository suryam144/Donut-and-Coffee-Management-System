package com.example.cs213_p5;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;

import java.text.DecimalFormat;
import java.util.ArrayList;

/**
 * DonutOrderActivity class, which creates an implementation of the DonutOrderActivity page and allows you to order donuts upon selection
 * @authors Isabelle Chang, Surya Mantha
 */
public class DonutOrderActivity extends AppCompatActivity {

    ListView dOrderList;
    Button dRemoveItem;
    Button dAddBasket;
    Button dAddMoreDonuts;
    TextInputEditText dSubtotal;

    private int index = -1;
    private double tempPrice = 0;
    private ArrayList<String> orderList = new ArrayList<>();
    private int orderCount = 0;

    /**
     * Method that creates the DonutOrderActivity scene upon selection in the ItemSelectedActivity page
     * @param savedInstanceState Bundle used to create the DonutOrderActivity scene
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.donut_order);

        dOrderList = findViewById(R.id.dOrderList);
        dRemoveItem = findViewById(R.id.doRIButton);
        dAddBasket = findViewById(R.id.doAddBasketButton);
        dAddMoreDonuts = findViewById(R.id.doAddMoreDonuts);
        dSubtotal = findViewById(R.id.doSubtotal);

        ArrayAdapter adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, orderList);
        dOrderList.setAdapter(adapter);
        for(int i = 0; i < ItemSelectedActivity.getDonutList().size(); i++){
            orderList.add(ItemSelectedActivity.getDonutList().get(i).toString());
            tempPrice += ItemSelectedActivity.getDonutList().get(i).itemPrice();
        }
        dOrderList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            /**
             * Method that finds the index of a selected ListView Item
             * @param adapterView adapterView of the listview
             * @param view view of the listview
             * @param i index of the list view
             * @param l long value for the list view when clicked
             */
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                index = i;
            }
        });
        DecimalFormat fmt = new DecimalFormat("##,###0.00");
        dSubtotal.setText("$" + fmt.format(tempPrice));
    }

    /**
     * Method that removes an item from a list of donuts
     * @param view View of Donut Orders
     */
    public void dRemoveItem(View view) {
        if(ItemSelectedActivity.getDonutList().size() < 1){
            alertEmptyBasket(view);
        }
        else if(index < 0){
            alertSelect();
        }
        else{
            orderList.clear();
            ItemSelectedActivity.getDonutList().remove(index);
            for(int i = 0; i < ItemSelectedActivity.getDonutList().size(); i++){
                orderList.add(ItemSelectedActivity.getDonutList().get(i).toString());
            }
            ArrayAdapter adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, orderList);
            dOrderList.setAdapter(adapter);
            tempPrice = 0;
            for(int i = 0; i < ItemSelectedActivity.getDonutList().size(); i++){
                tempPrice += ItemSelectedActivity.getDonutList().get(i).itemPrice();
            }
            DecimalFormat fmt = new DecimalFormat("##,###0.00");
            dSubtotal.setText("$" + fmt.format(tempPrice));
            index = -1;
        }
    }

    /**
     * Method that adds an order of donuts to the basket
     * @param view View of Donut Orders to be added to the basket
     */
    public void dAddBasket(View view) {
        if(ItemSelectedActivity.getDonutList().size() < 1){
            alertEmptyBasket(view);
            /*finishAffinity();
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);*/
        }
        else{
            Order tempOrder = new Order(orderCount);
            Context context = getApplicationContext();
            for(int i = 0; i < ItemSelectedActivity.getDonutList().size(); i++){
                tempOrder.add(ItemSelectedActivity.getDonutList().get(i));
            }
            Toast.makeText(context, "The following order was added to the basket.",Toast.LENGTH_SHORT).show();
            MainActivity.addOrder(tempOrder);
            ItemSelectedActivity.getDonutList().clear();
            orderCount++;
            finishAffinity();
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        }
    }

    /**
     * Method that allows the user to add more donuts
     * @param view View of donut orders to add more donuts
     */
    public void dAddMoreDonuts(View view){
        Intent intent = new Intent(this, DonutActivity2.class);
        startActivity(intent);
    }

    /**
     * Method that creates an alert if no item is selected in the listview
     */
    public void alertSelect(){
        AlertDialog.Builder alert = new AlertDialog.Builder(this);
        alert.setTitle("Error!");
        alert.setMessage("Order has not been selected");
        alert.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
            /**
             * Method that creates a positive button upon creating an alert
             * @param dialogInterface dialogInterface for an alert
             * @param i Integer for index
             */
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
            }
        });
        alert.create().show();
    }

    /**
     * Method that creates an alert if the basket is empty upon removal of items
     */
    public void alertEmptyBasket(View view){
        AlertDialog.Builder alert = new AlertDialog.Builder(this);
        alert.setTitle("Error!");
        alert.setMessage("Order could not be made. Basket is empty.");
        alert.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
            /**
             * Method that creates a positive button upon creating an alert
             * @param dialogInterface dialogInterface for an alert
             * @param i Integer for index
             */
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                finishAffinity();
                Intent intent = new Intent(view.getContext(), MainActivity.class);
                startActivity(intent);
            }
        });
        alert.create().show();

    }

}