package com.example.cs213_p5;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import java.text.DecimalFormat;
import java.util.ArrayList;

/**
 * ItemSelectedActivity Class, which creates an implementation of the activity item selected xml file and allows you to choose the quantity of donuts
 * @authors Isabelle Chang, Surya Mantha
 */
public class ItemSelectedActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    private TextView donutName;
    private TextView donutPrice;
    private Spinner dQuantSpinner;
    private Button addToDOButton;
    private String tempDonutName;
    private Donut tempDonut;
    private static ArrayList<Donut> tempDonutList = new ArrayList<>();

    /**
     * Method that creates the ItemSelectedActivity scene upon selection in the DonutActivity page
     * @param savedInstanceState Bundle used to create the ItemSelectedActivity scene
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_selected);
        donutName = findViewById(R.id.donutName);
        donutPrice = findViewById(R.id.donutPrice);
        addToDOButton = findViewById(R.id.addToDOButton);
        dQuantSpinner = findViewById(R.id.dQuantSpinner);
        Intent intent1 = getIntent();
        tempDonutName = intent1.getStringExtra("ITEM");
        donutName.setText(tempDonutName);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.donutAmt, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        dQuantSpinner.setAdapter(adapter);
        dQuantSpinner.setOnItemSelectedListener(this);

    }

    /**
     * Method used to open the Donut Order to complete order
     * @param view View of openDonutOrderActivity page
     */
    public void openDonutOrderActivity(View view){
        tempDonutList.add(tempDonut);
        Intent intent = new Intent(this, DonutOrderActivity.class);
        startActivity(intent);
    }

    /**
     * Method that completes an action upon spinner being selected
     * @param adapterView View of screen
     * @param view view of item select
     * @param i index of item location
     * @param l length at item location
     */
    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
        int donutAmt = Integer.parseInt(dQuantSpinner.getSelectedItem().toString());
        if(tempDonutName.equals("Chocolate Glazed Donut Hole") || tempDonutName.equals("Glazed Donut Hole")
                || tempDonutName.equals("Powdered Sugar Donut Hole") || tempDonutName.equals("Pumpkin Donut Hole")){
            tempDonut = new Donut("Donut", "Holes", tempDonutName, donutAmt);
        }
        else if(tempDonutName.equals("Boston Creme") || tempDonutName.equals("Chocolate Frosted")
        || tempDonutName.equals("Strawberry Frosted") || tempDonutName.equals("Vanilla Frosted")){
            tempDonut = new Donut("Donut", "Yeast", tempDonutName, donutAmt);
        }
        else if(tempDonutName.equals("Blueberry") || tempDonutName.equals("Cinnamon Sugar")
                || tempDonutName.equals("Coconut") || tempDonutName.equals("Sour Cream")){
            tempDonut = new Donut("Donut", "Cake", tempDonutName, donutAmt);
        }
        DecimalFormat fmt = new DecimalFormat("##,###0.00");
        donutPrice.setText("$" + fmt.format(tempDonut.itemPrice()));
    }
    /**
     * Loaded method required upon implementation
     * @param adapterView View of screen
     */
    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }

    /**
     * Method that returns the variable tempDonutList, a list of all donuts made
     * @return ArrayList<Donut> Returns the variable tempDonutList
     */
    public static ArrayList<Donut> getDonutList(){
        return tempDonutList;
    }
}