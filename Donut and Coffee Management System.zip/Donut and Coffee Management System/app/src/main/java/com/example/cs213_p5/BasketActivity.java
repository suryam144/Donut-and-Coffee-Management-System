package com.example.cs213_p5;

import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputEditText;

import java.text.DecimalFormat;
import java.util.ArrayList;

/**
 * BasketActivity class, which creates an instance of a BasketActivity page to manage orders
 * @authors Isabelle Chang, Surya Mantha
 */
public class BasketActivity extends AppCompatActivity {

    ListView basketList;
    Button indivCosts;
    Button totCosts;
    Button removeItem;
    Button placeOrder;
    TextInputEditText bBasketSubtotal;
    TextInputEditText bSalesTax;
    TextInputEditText bBasketTotal;

    private static final double SALES_TAX = 0.0625;
    private ArrayList<String> orderList = new ArrayList<>();
    private int index = -1;

    /**
     * Method that creates the BasketActivity scene upon selection in the MainActivity page
     * @param savedInstanceState Bundle used to create the BasketActivity scene
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.basket_view);

        basketList = findViewById(R.id.bOrderList);
        indivCosts = findViewById(R.id.bViewICButton);
        totCosts = findViewById(R.id.bViewTCButton);
        removeItem = findViewById(R.id.RIButton);
        placeOrder = findViewById(R.id.bPOButton);

        bBasketSubtotal = findViewById(R.id.bSubtotal);
        bSalesTax = findViewById(R.id.bSalesTax);
        bBasketTotal = findViewById(R.id.bTotal);

        for(int i = 0; i < MainActivity.getTotalStore().getOrderArr().size(); i++){
            orderList.add(MainActivity.getTotalStore().getOrderArr().get(i).getOrder(false));
        }
        ArrayAdapter adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, orderList);
        basketList.setAdapter(adapter);
        basketList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            /**
             * Method that finds the index of a selected ListView Item
             * @param adapterView adapterView of the listview
             * @param view view of the listview
             * @param i index of the list view
             * @param l long value for the list view when clicked
             */
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                index = i;
            }
        });
    }

    /**
     * Method that allows you to view the costs of an individual order in a basket
     * @param view View of bViewCosts
     */
    public void bViewCosts(View view) {
        if(MainActivity.getTotalStore().getOrderArr().size() < 1){
            alertEmptyBasket();
        }
        else if(index < 0){
            alertSelect();
        }
        else{
            DecimalFormat fmt = new DecimalFormat("##,###0.00");
            double basketVal = MainActivity.getTotalStore().getOrderArr().get(index).orderTotal();
            double basketTax = MainActivity.getTotalStore().getOrderArr().get(index).orderTotal() * SALES_TAX;
            double basketTot = basketVal + basketTax;
            bBasketSubtotal.setText("$" + fmt.format(basketVal));
            bSalesTax.setText("$" + fmt.format(basketTax));
            bBasketTotal.setText("$" + fmt.format(basketTot));
        }
    }

    /**
     * Method that returns the total cost of all the orders within a basket
     * @param view View of bTotalCosts
     */
    public void bTotalCosts(View view) {
        if(MainActivity.getTotalStore().getOrderArr().size() < 1){
            alertEmptyBasket();
        }
        else{
            DecimalFormat fmt = new DecimalFormat("##,###0.00");
            double temp = 0;
            for(int j = 0; j < MainActivity.getTotalStore().getOrderArr().size(); j++){
                temp += MainActivity.getTotalStore().getOrderArr().get(j).orderTotal();
            }
            double basketVal = temp;
            double basketTax = temp * SALES_TAX;
            double basketTot = basketVal + basketTax;
            bBasketSubtotal.setText("$" + fmt.format(basketVal));
            bSalesTax.setText("$" + fmt.format(basketTax));
            bBasketTotal.setText("$" + fmt.format(basketTot));
        }
    }

    /**
     * Method that removes an order from a basket
     * @param view View of bRemoveItem
     */
    public void bRemoveItem(View view) {
        if(MainActivity.getTotalStore().getOrderArr().size() < 1){
            alertEmptyBasket();
        }
        else if(index < 0){
            alertSelect();
        }
        else {
            orderList.clear();
            MainActivity.removeOrder(MainActivity.getTotalStore().getOrderArr().get(index));
            for(int i = 0; i < MainActivity.getTotalStore().getOrderArr().size(); i++){
                orderList.add(MainActivity.getTotalStore().getOrderArr().get(i).getOrder(false));
            }
            ArrayAdapter adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, orderList);
            basketList.setAdapter(adapter);
            bBasketSubtotal.setText(" ");
            bSalesTax.setText(" ");
            bBasketTotal.setText(" ");
            index = -1;
        }
    }

    /**
     * Method that places an order of items within a basket
     * @param view View of bPlaceOrder
     */
    public void bPlaceOrder(View view) {
        if(MainActivity.getTotalStore().getOrderArr().size() < 1){
            alertEmptyBasket();
        }
        else{
            Context context = getApplicationContext();
            orderList.clear();
            StoreOrders finalStore = new StoreOrders();
            for(int i = 0; i < MainActivity.getTotalStore().getOrderArr().size(); i++){
                finalStore.add(MainActivity.getTotalStore().getOrderArr().get(i));
            }
            MainActivity.addTotalOrder(finalStore);
            for(int i = 0; i < MainActivity.getTotalStore().getOrderArr().size(); i++){
                MainActivity.removeOrder(MainActivity.getTotalStore().getOrderArr().get(i));
            }
            Toast.makeText(context, "The following basket was added as an order.",Toast.LENGTH_SHORT).show();
            bBasketSubtotal.setText(" ");
            bSalesTax.setText(" ");
            bBasketTotal.setText(" ");
            finish();

        }
    }

    /**
     * Method that creates an alert if no item is selected in the listview
     */
    public void alertSelect(){
        AlertDialog.Builder alert = new AlertDialog.Builder(this);
        alert.setTitle("Error!");
        alert.setMessage("Order has not been selected");
        alert.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
            /**
             * Method that creates a positive button upon creating an alert
             * @param dialogInterface dialogInterface for an alert
             * @param i Integer for index
             */
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
            }
        });
        alert.create().show();
    }

    /**
     * Method that creates an alert if the basket is empty upon removal of items
     */
    public void alertEmptyBasket(){
        AlertDialog.Builder alert = new AlertDialog.Builder(this);
        alert.setTitle("Error!");
        alert.setMessage("Order could not be made. Basket is empty.");
        alert.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
            /**
             * Method that creates a positive button upon creating an alert
             * @param dialogInterface dialogInterface for an alert
             * @param i Integer for index
             */
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                finish();
            }
        });
        alert.create().show();
    }
}

