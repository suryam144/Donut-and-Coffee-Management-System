package com.example.cs213_p5;

import android.content.Context;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputEditText;

import java.io.Serializable;
import java.text.DecimalFormat;

/**
 * CoffeeActivity class, which creates an implementation of a CoffeeActivity page to select coffee
 * @authors Isabelle Chang, Surya Mantha
 */
public class CoffeeActivity extends AppCompatActivity implements Serializable, AdapterView.OnItemSelectedListener{

    private StoreOrders tempStore = new StoreOrders();
    private int orderCount = 0;
    private Coffee tempCoffee;
    private double tempAmt = 0;
    private double addOnAmt = 0;

    private TextInputEditText cPriceAmt;
    private CheckBox creamCheckBox;
    private CheckBox caramelCheckBox;
    private CheckBox milkCheckBox;
    private CheckBox syrupCheckBox;
    private CheckBox whippedCreamCheckBox;

    private Spinner cSizeSpinner;
    private Spinner cQuantSpinner;
    private String cSize;
    private int cQuant;

    /**
     * Method that creates the CoffeeActivity scene upon selection in the MainActivity page
     * @param savedInstanceState Bundle used to create the CoffeeActivity scene
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.coffee_view);
        setTitle(getIntent().getStringExtra("COFFEE"));

        cPriceAmt = findViewById(R.id.sSubField);
        creamCheckBox = findViewById(R.id.creamCheckbox);
        caramelCheckBox = findViewById(R.id.caramelCheckBox);
        milkCheckBox = findViewById(R.id.milkCheckbox);
        syrupCheckBox = findViewById(R.id.syrupCheckbox);
        whippedCreamCheckBox = findViewById(R.id.whippedCreamCheckbox);

        creamCheckBox.setChecked(false);
        caramelCheckBox.setChecked(false);
        milkCheckBox.setChecked(false);
        syrupCheckBox.setChecked(false);
        whippedCreamCheckBox.setChecked(false);

        cSizeSpinner = findViewById(R.id.cSizeSpinner);
        cQuantSpinner = findViewById(R.id.cQuantSpinner);

        ArrayAdapter<CharSequence> adapterOne = ArrayAdapter.createFromResource(this, R.array.coffeeType, android.R.layout.simple_spinner_item);
        adapterOne.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        cSizeSpinner.setAdapter(adapterOne);
        cSizeSpinner.setOnItemSelectedListener(this);

        ArrayAdapter<CharSequence> adapterTwo = ArrayAdapter.createFromResource(this, R.array.coffeeAmt, android.R.layout.simple_spinner_item);
        adapterTwo.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        cQuantSpinner.setAdapter(adapterTwo);
        cQuantSpinner.setOnItemSelectedListener(this);
    }

    /**
     * Method used to calculate the price of a selected coffee
     * @param view priceCalculate view
     */
    public void priceCalculate(View view){
        DecimalFormat fmt = new DecimalFormat("##,###0.00");
        cPriceAmt.setText("$" + fmt.format(calculatePrice()));
    }

    /**
     * Method used to add a coffee to a basket
     * @param view addBasket view
     */
    public void cAddBasket(View view) {
        Context context = getApplicationContext();
        if(cSizeSpinner.getSelectedItem() == null){Toast.makeText(context,"Error: Size of Coffee was not selected.",Toast.LENGTH_SHORT).show();}
        else if(cQuantSpinner.getSelectedItem() == null){Toast.makeText(context, "Error: Quantity of Coffee was not selected.",Toast.LENGTH_SHORT).show();}
        else{
            int tempAmt = Integer.parseInt(cQuantSpinner.getSelectedItem().toString());
            tempCoffee = new Coffee("Coffee", cSizeSpinner.getSelectedItem().toString(), tempAmt);
            if(caramelCheckBox.isChecked()){tempCoffee.add("Caramel");}
            if(creamCheckBox.isChecked()){tempCoffee.add("Cream");}
            if(milkCheckBox.isChecked()){tempCoffee.add("Milk");}
            if(syrupCheckBox.isChecked()){tempCoffee.add("Syrup");}
            if(whippedCreamCheckBox.isChecked()){tempCoffee.add("Whipped Cream");}
            Toast.makeText(context, "The following order was added to the basket.",Toast.LENGTH_SHORT).show();
            Order tempOrder = new Order(orderCount);
            tempOrder.add(tempCoffee);
            tempStore.add(tempOrder);
            orderCount++;
            MainActivity.addOrder(tempOrder);
            finish();
        }
    }

    /**
     * Method used to calculate price on spinner selection
     * @param adapterView View of screen
     * @param view view of item select
     * @param i index of item location
     * @param l length at item location
     */
    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
        DecimalFormat fmt = new DecimalFormat("##,###0.00");
        cPriceAmt.setText("$" + fmt.format(calculatePrice()));
    }

    /**
     * Loaded method required upon implementation
     * @param adapterView View of screen
     */
    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {
    }

    /**
     * Method used to calculate price of a coffee
     * @return Returns price of a coffee
     */
    public double calculatePrice(){
        if(cSizeSpinner.getSelectedItem() == null){return 0;}
        double temp = 1.69;
        if(cQuantSpinner.getSelectedItem() == null){return 0;}
        int amt = Integer.parseInt(cQuantSpinner.getSelectedItem().toString());
        if(cSizeSpinner.getSelectedItem().toString().equals("Tall")){ temp += 0.40;}
        else if(cSizeSpinner.getSelectedItem().toString().equals("Grande")){ temp += 0.80;}
        else if(cSizeSpinner.getSelectedItem().toString().equals("Venti")){ temp += 1.20;}
        if(caramelCheckBox.isChecked()){temp += (0.30); }
        if(creamCheckBox.isChecked()){temp += (0.30);}
        if(milkCheckBox.isChecked()){temp += (0.30);}
        if(syrupCheckBox.isChecked()){temp += (0.30);}
        if(whippedCreamCheckBox.isChecked()){temp += (0.30);}
        temp *= amt;
        return temp;
    }
}
