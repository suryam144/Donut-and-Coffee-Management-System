package com.example.cs213_p5;

import android.content.Context;
import android.content.Intent;
import android.text.Layout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

/**
 * DonutAdapter2 class, which creates an implementation of DonutAdapter2, which creates the different rows in a RecyclerView
 * @authors Isabelle Chang, Surya Mantha
 */
class DonutAdapter2 extends RecyclerView.Adapter<DonutAdapter2.ItemsHolder> {
    private Context context;
    private ArrayList<DonutModel> donutModels;
    private Spinner dQuantSpinner;

    /**
     * Constructor for the DonutAdapter2 Class
     * @param context Context for the DonutAdapter2 Class
     * @param donutModels donutModels used for the RecyclerView
     */
    public DonutAdapter2(Context context, ArrayList<DonutModel> donutModels) {
        this.context = context;
        this.donutModels = donutModels;
    }

    /**
     * Method that creaters a LayoutInflator for the RecyclerView
     * @param parent Parent for the ViewHolder
     * @param viewType ViewType for the DonutAdapter2 class
     * @return DonutAdapter2.ItemsHolder: Returns a view that serves as the RecyclerView
     */
    @NonNull
    @Override
    public DonutAdapter2.ItemsHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        //inflate layout (giving a look to our rows)
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.donut_row, parent, false);
        return new DonutAdapter2.ItemsHolder(view);

    }

    /**
     * Method that binds the View Holder for the RecyclerView
     * @param holder Holder for the ViewHolder
     * @param position Position of the RecyclerView
     */
    @Override
    public void onBindViewHolder(@NonNull DonutAdapter2.ItemsHolder holder, int position) {
        //assign values to the views we created in donut_row layout
        //based on position of recycler view
        holder.tvFlavor.setText(donutModels.get(position).getDonutFlavor());
        holder.tvPrice.setText(donutModels.get(position).getDonutPrice());
        holder.donutImage.setImageResource(donutModels.get(position).getDonutImage());
    }

    /**
     * Method that returns the size of the models displayed in the recycler view
     * @return Integer: Size of the variable donutModels
     */
    @Override
    public int getItemCount() {
        //how many items dow e want ot be displayed at once?
        return donutModels.size();
    }

    /**
     * ItemsHolder class, which serves to hold items in a recycler view
     * @authors Isabelle Chang, Surya Mantha
     */
    public static class ItemsHolder extends RecyclerView.ViewHolder {
        //get views from donutrow xml file
        //similar to oncreate method

        private ImageView donutImage;
        private TextView tvFlavor, tvPrice;
        private Spinner dQuantSpinner;
        private Button addButton;
        private ConstraintLayout parentLayout;

        /**
         * ItemHolders Constructor, which holds items for the RecyclerView
         * @param itemView View of the ItemsHolder for the RecyclerView
         */
        public ItemsHolder(@NonNull View itemView) {
            super(itemView);

            donutImage = itemView.findViewById(R.id.donutImage);
            tvFlavor = itemView.findViewById(R.id.donutFlavorText);
            tvPrice = itemView.findViewById(R.id.donutPriceText);
            dQuantSpinner = itemView.findViewById(R.id.dQuantSpinner);
            parentLayout = itemView.findViewById(R.id.rowLayout);

            parentLayout.setOnClickListener(new View.OnClickListener() {
                /**
                 * Method that shows the itemView upon click
                 * @param view View of ItemHolders
                 */
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(itemView.getContext(), ItemSelectedActivity.class);
                    intent.putExtra("ITEM", tvFlavor.getText());
                    itemView.getContext().startActivity(intent);
                }
            });
        }

        }
}

