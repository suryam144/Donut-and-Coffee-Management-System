package com.example.cs213_p5;
import java.text.DecimalFormat;
import java.util.ArrayList;

/**
 * Coffee Class, which creates and implements an instance of a Coffee drink
 * @author Isabelle Chang, Surya Mantha
 */
public class Coffee extends MenuItem implements Customizable{
    private String menuType;
    private String coffeeSize;
    private ArrayList<String> addOns;
    private double coffeePrice;
    private int coffeeAmt;

    /**
     * Creates an instance of a coffee item
     * @param menuType String: Specifies type of menu item
     * @param coffeeSize String: Specifies size of coffee
     * @param coffeeAmt Integer: Indicates how many units of coffee are being ordered
     */
    public Coffee(String menuType, String coffeeSize, int coffeeAmt){
        super(menuType);
        this.coffeeSize = coffeeSize;
        addOns = new ArrayList<>();
        DecimalFormat fmt = new DecimalFormat("##,###0.00");
        double tempPrice = 1.69;
        if(coffeeSize.equals("Tall")) {tempPrice += 0.40;}
        else if(coffeeSize.equals("Grande")){tempPrice += 0.80;}
        else if(coffeeSize.equals("Venti")){tempPrice += 1.20;}
        coffeePrice = Double.parseDouble(fmt.format(tempPrice));
        this.coffeeAmt = coffeeAmt;
    }

    /**
     * Method that returns the price of a coffee drink
     * @return Double: Returns price of a coffee drink
     */
    @Override
    public double itemPrice(){
        DecimalFormat fmt = new DecimalFormat("##,###0.00");
        return Double.parseDouble(fmt.format(coffeePrice * coffeeAmt));
    }

    /**
     * Method that adds addOns to a coffee, increasing its price
     * @param obj Obj: String that serves as the add on
     * @return Boolean: True if add is completed
     */
    @Override
    public boolean add(Object obj) {
        String temp = (String) obj;
        addOns.add(temp);
        coffeePrice += 0.30;
        return true;
    }

    /**
     * Method that removes addOns to a coffee, decreasing its price
     * @param obj Obj: String that serves as the add on
     * @return Boolean: true if remove is possible, false otherwise
     */
    @Override
    public boolean remove(Object obj) {
        String temp = (String) obj;
        boolean test = addOns.remove(temp);
        if(test){coffeePrice -= 0.30;}
        return test;
    }

    /**
     * Method that returns the selection of coffee as a String
     * @return String: Components of coffee as a String
     */
    @Override
    public String toString(){
        String temp = "";
        if(addOns.size() == 0){temp += "None";}
        else{
            for(int i = 0; i < addOns.size() - 1; i++){
                temp += addOns.get(i) + ", ";
            }
            temp += addOns.get(addOns.size() - 1);
        }
        return super.toString() +"::" + coffeeSize + "::[Add Ons: " + temp + "]::Amount " + coffeeAmt + "::Cost: " + itemPrice();
    }

    /**
     * Method that returns the size of coffee
     * @return String: Name of coffee size
     */
    public String getSize(){
        return coffeeSize;
    }

    /**
     * Method that returns the add ons on the coffee
     * @return ArrayList<String>: Returns add ons of the selected coffee
     */
    public ArrayList<String> getAddOn(){
        return addOns;
    }
}
