package com.example.cs213_p5;

import java.text.DecimalFormat;
import java.util.ArrayList;

/**
 * Order Class, which creates an implementation of an Order object
 * @authors Isabelle Chang, Surya Mantha
 */
public class Order implements Customizable{
    private ArrayList<MenuItem> menuList;
    private int orderNumber;
    private static final double SALES_TAX = 0.0625;

    /**
     * Inititalization of an order item
     * @param orderNumber Integer: Order number for Order
     */
    public Order(int orderNumber){
        this.orderNumber = orderNumber;
        menuList = new ArrayList<MenuItem>();
    }

    /**
     * Method that adds a Menu Item to an order
     * @param obj Obj: MenuItem to be added to orders
     * @return Boolean: True if an item has been added to an order; false otherwise
     */
    @Override
    public boolean add(Object obj) {
        if(obj instanceof Donut){
            Donut tempDonut = (Donut) obj;
            menuList.add(tempDonut);
            return true;
        }
        else if(obj instanceof Coffee){
            Coffee tempCoffee = (Coffee) obj;
            menuList.add(tempCoffee);
            return true;
        }
        return false;
    }

    /**
     * Method that removes a Menu Item to an order
     * @param obj Obj: MenuItem to be added to orders
     * @return Boolean: True if an item has been removed to an order; false otherwise
     */
    @Override
    public boolean remove(Object obj) {
        if(obj instanceof Donut){
            Donut tempDonut = (Donut) obj;
            int index = -1;
            for(int i = 0; i < menuList.size(); i++){
                if(menuList.get(i).toString().equals(tempDonut.toString())){
                    index = i;
                }
            }
            if(index == -1){return false;}
            menuList.remove(index);
            return true;
        }
        else if(obj instanceof Coffee){
            Coffee tempCoffee = (Coffee) obj;
            int index = -1;
            for(int i = 0; i < menuList.size(); i++){
                if(menuList.get(i).toString().equals(tempCoffee.toString())){
                    index = i;
                }
            }
            if(index == -1){return false;}
            menuList.remove(index);
            return true;
        }
        return false;
    }

    /**
     * Method that prints out the Order as a String
     * @return String: String that lists components of an order
     */
    public String getOrder(boolean tax){
        String temp = "**List of Order**\n";
        temp += printOrder(tax);
        return temp + "**End of List**";
    }

    /**
     * Method that returns the order number for an order
     * @return Integer: Returns the order number for an order
     */
    public int getOrderNumber(){
        return orderNumber;
    }

    /**
     * Method that prints the components of an order
     * @param tax Boolean: Determines if Tax should be incorporated into the price
     * @return String: Returns the components of an order
     */
    public String printOrder(boolean tax){
        String temp = "";
        double tempPrice = 0;
        for (int i = 0; i < menuList.size(); i++) {
            temp += (menuList.get(i).toString() + "\n");
        }
        DecimalFormat fmt = new DecimalFormat("##,###0.00");
        if(!tax){tempPrice = orderTotal();}
        else{tempPrice = (orderTotal() * SALES_TAX) + orderTotal();}
        return temp + "Total: " + fmt.format(tempPrice) + "\n";
    }

    /**
     * Method that returns the total of combined orders
     * @return Double: Price of all items in an order
     */
    public double orderTotal(){
        double tempPrice = 0;
        for(int i = 0; i < menuList.size(); i++){
            tempPrice += menuList.get(i).itemPrice();
        }
        DecimalFormat fmt = new DecimalFormat("##,###0.00");
        return Double.parseDouble(fmt.format(tempPrice));
    }

    /**
     * Method that sets an order's order number
     * @param val Integer: Order number to be set
     * @return Boolean: True if completed
     */
    public boolean setOrderNumber(int val){
        orderNumber = val;
        return true;
    }
}
