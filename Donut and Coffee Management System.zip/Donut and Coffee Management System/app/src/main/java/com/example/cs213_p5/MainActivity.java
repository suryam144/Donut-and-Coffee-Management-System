package com.example.cs213_p5;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.textfield.TextInputEditText;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * MainActivity class, which creates an instance of the MainActivity page and manages the other Activity classes and pages
 */
public class MainActivity extends AppCompatActivity implements Serializable {

    private static StoreOrders totalStore = new StoreOrders();
    private static ArrayList<StoreOrders> orderStore = new ArrayList<>();

    /**
     * Method that creates the MainActivity scene upon selection in the MainActivity page
     * @param savedInstanceState Bundle used to create the MainActivity scene
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    /**
     * Method that opens the Coffee Page to order a coffee
     * @param view View portion of the CoffeeActivity page
     */
    public void openCoffee(View view){
        Intent intent = new Intent(this, CoffeeActivity.class);
        startActivity(intent);
    }

    /**
     * Method that opens the Donut to order a donut
     * @param view View portion of the DonutActivity2 page
     */
    public void openDonut(View view){
        Intent intent = new Intent(this, DonutActivity2.class);
        startActivity(intent);
    }

    /**
     * Method that opens the BasketPage to view the basket
     * @param view View portion of the BasketActivity page
     */
    public void openBasket(View view){
        if(totalStore.getOrderArr().size() < 1){
            AlertDialog.Builder alert = new AlertDialog.Builder(this);
            alert.setTitle("Error!");
            alert.setMessage("No order has been added to basket");
            alert.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                }
            });
            alert.create().show();
        }
        else{
            Intent intent = new Intent(this, BasketActivity.class);
            startActivity(intent);
        }
    }

    /**
     * Method that opens the ListOrdersActivity page to view all orders
     * @param view View portion of the ListOrdersActivity page
     */
    public void openList(View view){
        if(orderStore.size() < 1){
            AlertDialog.Builder alert = new AlertDialog.Builder(this);
            alert.setTitle("Error!");
            alert.setMessage("No basket order has been placed yet");
            alert.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                }
            });
            alert.create().show();
        }
        else {
            Intent intent = new Intent(this, ListOrdersActivity.class);
            startActivity(intent);
        }
    }

    /**
     * Method that adds an order to the totalStore variable
     * @param order Order to be added to the totalStore variable
     */
    public static void addOrder(Order order){totalStore.add(order);}
    /**
     * Method that removes an order to the totalStore variable
     * @param order Order to be removed to the totalStore variable
     */
    public static void removeOrder(Order order){totalStore.remove(order);}

    /**
     * Method that adds an order to the orderStore variable
     * @param so StoreOrder to be added to the orderStore variable
     */
    public static void addTotalOrder(StoreOrders so){orderStore.add(so);}

    /**
     * Method that returns the totalStore variable
     * @return totalStore: Returns the totalStore variable
     */
    public static StoreOrders getTotalStore(){return totalStore;}
    /**
     * Method that returns the orderStore variable
     * @return orderStore: Returns the orderStore variable
     */
    public static ArrayList<StoreOrders> getOrderStore(){return orderStore;}


}
