package com.example.cs213_p5;

/**
 * Method that incorporates adding and removing for additional classes
 * @authors Isabelle Chang, Surya Mantha
 */
public interface Customizable {
    /**
     * Method that adds components to an Order
     * @param obj Obj: MenuItem to be added to orders
     * @return True if added successfully
     */
    boolean add(Object obj);
    /**
     * Method that removes components to an Order
     * @param obj Obj: MenuItem to be removed to orders
     * @return True if removed successfully; false otherwise
     */
    boolean remove(Object obj);
}
