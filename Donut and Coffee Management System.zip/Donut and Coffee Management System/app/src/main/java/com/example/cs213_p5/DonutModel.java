package com.example.cs213_p5;

/**
 * DonutModel class, which serves as a model of a Donut for the Recycler View
 * @author Isabelle Chang, Surya Mantha
 */
public class DonutModel {
    String donutFlavor;
   // String donutType;
    String donutPrice;
    String donutQuant;
    int donutImage;

    /**
     * DonutModel Constructor, which allows the implementation of a DonutModel
     * @param donutFlavor Flavor of DOnut
     * @param donutPrice Price of Donut
     * @param donutImage Image of Donut
     */
    public DonutModel(String donutFlavor, String donutPrice, int donutImage) {
        this.donutFlavor = donutFlavor;
        this.donutPrice = donutPrice;
        //this.donutQuant = donutQuant;
        this.donutImage = donutImage;
    }

    /**
     * Returns the flavor of Donut
     * @return String: Variable donutFlavor
     */
    public String getDonutFlavor() {
        return donutFlavor;
    }
    /**
     * Returns the price of Donut
     * @return String: Variable donutPrice
     */
    public String getDonutPrice() {
        return donutPrice;
    }

    /**
     * Returns the quantity of Donut
     * @return String: Variable donutQuant
     */
    public String getDonutQuant() {
        return donutQuant;
    }

    /**
     * Returns the Image of Donut
     * @return Integer: Variable donutImage
     */
    public int getDonutImage() {
        return donutImage;
    }
}
